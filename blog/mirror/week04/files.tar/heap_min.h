#include <stdbool.h>
#include <stdlib.h>

#ifndef HEAP_MIN_H_
#define HEAP_MIN_H_

bool heap_min_p (int heap[], size_t heap_size);

#endif /* !defined(HEAP_MIN_H_) */
