// COMP2521 19T0 ... lab 01: test a linked list implementation
//
// YYYY-mm-dd	Your Name Here <zNNNNNNN@student.unsw.edu.au>

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "lists.h"

int main (void)
{
	// Creates an empty list, and then prints it.
	link list = NULL;
	list_print (list);

	// You should write some tests here. (And remove this comment.)

	return EXIT_SUCCESS;
}
